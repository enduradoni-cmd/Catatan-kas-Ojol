# Mitra Ojol Kas — Android WebView

Project Android pembungkus situs Mitra Ojol Kas.

## Konfigurasi
- Nama aplikasi: Mitra Ojol Kas
- Package: `com.donicitra.mitraojolkas`
- Minimum Android: Android 6.0 (API 23)
- Target SDK: 35
- JavaScript dan DOM Storage aktif
- Cookie diaktifkan agar sesi login situs dapat dipertahankan
- URL awal: https://mitra-ojol-kas--8ctp1y3i.preview.emergentagent.com/

## Build APK
Project ini adalah source project Android, bukan file APK yang sudah dikompilasi.
Untuk menghasilkan APK diperlukan Android SDK dan Gradle:
1. Buka project ini di Android Studio atau layanan build Android cloud.
2. Jalankan tugas `:app:assembleDebug`.
3. APK debug akan dibuat di `app/build/outputs/apk/debug/app-debug.apk`.

Untuk APK distribusi, buat signing key sendiri dan jalankan `:app:assembleRelease` dengan konfigurasi signing yang aman.
Jangan membagikan signing key atau kata sandinya.

## Catatan
Aplikasi membutuhkan koneksi internet. Semua data dan autentikasi tetap dilayani oleh website; APK ini hanya menjadi wadah WebView dan tidak menyalin database atau backend situs.
